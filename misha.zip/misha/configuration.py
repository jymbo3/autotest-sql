# Антонов Михаил 30-ая когорта — Финальный проект. Инженер по тестированию плюс
URL_SERVICE = " https://42524cbd-7721-47ef-a987-deb24f7cdf84.serverhub.praktikum-services.ru"
CREATE_ORDER = "/api/v1/orders"
GET_ORDER_BY_NUMBER = "/api/v1/orders/track"