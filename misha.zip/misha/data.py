# Антонов Михаил 30-ая когорта — Финальный проект. Инженер по тестированию плюс
order_body = {
    "firstName": "Наруто",
    "lastName": "Учиха",
    "address": "Коноха, 142",
    "metroStation": 4,
    "phone": "+78003553535",
    "rentTime": 5,
    "deliveryDate": "2025-05-28",
    "comment": "Саске, вернись в Коноху",
    "color": [
        "BLACK"
    ]
}